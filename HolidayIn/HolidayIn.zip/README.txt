In this Project i have created 7 pages, Below i have mention link for each pages, you can access directly by clicking the links


Home - https://hotelholidayin.netlify.app/
Hotels List - https://hotelholidayin.netlify.app/post-listing
Hotel Details - https://hotelholidayin.netlify.app/hotel
Contaxct us - https://hotelholidayin.netlify.app/contact-us
Login - https://hotelholidayin.netlify.app/login
Create Account - https://hotelholidayin.netlify.app/register
FAQ - https://hotelholidayin.netlify.app/faq
